from flask import Flask,render_template,request,redirect,url_for,session,jsonify, flash
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField 
from wtforms.validators import DataRequired 
from flask_cors import CORS,cross_origin
import joblib
import pickle
import pandas as pd
import numpy as np
import csv 
import os

app = Flask(__name__)
CORS(app)
app.secret_key = 'Dodong RR'

# Load Dataset Models
# Classification
with open('C:/Users/user/OneDrive/Desktop/Test2/static/classification_model.pkl', 'rb') as model_file:
    password_classifier = pickle.load(model_file)

# Regression
with open('C:/Users/user/OneDrive/Desktop/Test2/static/RegressionModel.pkl', 'rb') as model_file:
    regression_model = pickle.load(model_file)


@app.route("/")
def index():
    return render_template('index.html')

@app.route("/classification")
def classification():
    return render_template('classification.html')

@app.route("/regression")
def regression():
    return render_template('regression.html')


# prediction for classification
@app.route('/predict_password', methods=['POST'])
def predict_password():
    try:
        data = request.get_json()
        password = data['password']
        
        # Perform prediction using the loaded classifier
        prediction = password_classifier.predict([password])[0]

        # Return the result as JSON
        return jsonify({'result': str(prediction)})

    except Exception as e:
        # Handle any exceptions and return an error response
        return jsonify({'error': str(e)})
    


# prediction for regression
@app.route("/predictreg", methods=['POST'])
def predict_reg():
    try:
        # Get the input data from the request
        data = request.get_json()

        # Convert data to a format suitable for regression prediction
        input_data = np.array([(data['company']), (data['product']), (data['typename']), (data['ram']), (data['memory'])]).reshape(1, 5)

        # Make the regression prediction
        prediction = regression_model.predict(input_data)[0]

        # Return the prediction as JSON
        return jsonify({'prediction': float(prediction)})  # Convert the prediction to float for JSON serialization
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == "__main__":
    app.run(debug=True)